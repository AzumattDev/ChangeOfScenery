# Description

## A simple mod that gives a welcoming change to the start menu of Valheim. A "Change Of Scenery" if you will. Configure the song playing, camera locations, or leave it alone and enjoy my settings.

`This mod is not needed on a server. It's client only. Install on each client that you wish to have the mod load.`

---


`Feel free to reach out to me on discord if you need manual download assistance.`


# Author Information

### Azumatt

`DISCORD:` Azumatt#2625

`STEAM:` https://steamcommunity.com/id/azumatt/

For Questions or Comments, find me in the Odin Plus Team Discord or in mine:

[![https://i.imgur.com/XXP6HCU.png](https://i.imgur.com/XXP6HCU.png)](https://discord.gg/Pb6bVMnFb2)
<a href="https://discord.gg/pdHgy6Bsng"><img src="https://i.imgur.com/Xlcbmm9.png" href="https://discord.gg/pdHgy6Bsng" width="175" height="175"></a>
***

> # Update Information (Latest listed first)

| `Version` | `Update Notes`   |
|-----------|------------------|
| 1.0.0     | - Initial Relase |
