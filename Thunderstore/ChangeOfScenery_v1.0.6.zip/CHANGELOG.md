| `Version` | `Update Notes`                                                                                                    |
|-----------|-------------------------------------------------------------------------------------------------------------------|
| 1.0.6     | - New default for fire position, make it update correctly. You can now move the player's fire where needed.       |
| 1.0.5     | - Update for latest Valheim version (Ashlands)                                                                    |
| 1.0.4     | - Update for latest Valheim version                                                                               |
| 1.0.3     | - Update for latest Valheim version                                                                               |
| 1.0.2     | - Fix an issue that could lock your game, preventing character creation if you didn't have any characters at all. |
| 1.0.1     | - Attempted fix at logout & back in issue causing the audio source to fail to load properly.                      |
| 1.0.0     | - Initial Release                                                                                                 |
